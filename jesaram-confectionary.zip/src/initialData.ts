import { ConfectioneryItem } from './types';

export const INITIAL_CONFECTIONERY_ITEMS: ConfectioneryItem[] = [
  {
    id: 'item-1',
    name: 'Shahi Sweet Supari (Premium)',
    price: 50.00,
    category: 'Sweet Suparis',
    createdAt: new Date('2026-06-01T10:00:00Z').toISOString()
  },
  {
    id: 'item-2',
    name: 'Tulsi Sweet Supari Pack',
    price: 30.00,
    category: 'Sweet Suparis',
    createdAt: new Date('2026-06-02T11:00:00Z').toISOString()
  },
  {
    id: 'item-3',
    name: 'Aroma Mint Supari',
    price: 20.00,
    category: 'Sweet Suparis',
    createdAt: new Date('2026-06-03T09:30:00Z').toISOString()
  },
  {
    id: 'item-4',
    name: 'Coca Cola 300ml Can',
    price: 120.00,
    category: 'Cold Drinks',
    createdAt: new Date('2026-06-04T14:15:00Z').toISOString()
  },
  {
    id: 'item-5',
    name: 'Sprite 500ml Can',
    price: 150.00,
    category: 'Cold Drinks',
    createdAt: new Date('2026-06-05T12:00:00Z').toISOString()
  },
  {
    id: 'item-6',
    name: 'Mineral Water 1L',
    price: 80.00,
    category: 'Cold Drinks',
    createdAt: new Date('2026-06-06T15:00:00Z').toISOString()
  },
  {
    id: 'item-7',
    name: "Baker's Butter Cookies",
    price: 180.00,
    category: 'Biscuits',
    createdAt: new Date('2026-06-07T08:00:00Z').toISOString()
  },
  {
    id: 'item-8',
    name: 'Chocolate Chip Biscuits',
    price: 140.00,
    category: 'Biscuits',
    createdAt: new Date('2026-06-08T16:45:00Z').toISOString()
  },
  {
    id: 'item-9',
    name: 'Zeera Plus Salted Biscuits',
    price: 100.00,
    category: 'Biscuits',
    createdAt: new Date('2026-06-09T09:00:00Z').toISOString()
  },
  {
    id: 'item-10',
    name: 'Creamy Butterscotch Candy',
    price: 10.00,
    category: 'Candies',
    createdAt: new Date('2026-06-10T11:30:00Z').toISOString()
  },
  {
    id: 'item-11',
    name: 'Mango Tango Tangy Candy',
    price: 5.00,
    category: 'Candies',
    createdAt: new Date('2026-06-11T12:30:00Z').toISOString()
  },
  {
    id: 'item-12',
    name: 'Spicy Masala Potato Chips',
    price: 80.00,
    category: 'Chips',
    createdAt: new Date('2026-06-12T13:30:00Z').toISOString()
  },
  {
    id: 'item-13',
    name: 'Classic Salted Wafers',
    price: 70.00,
    category: 'Chips',
    createdAt: new Date('2026-06-13T14:30:00Z').toISOString()
  },
  {
    id: 'item-14',
    name: 'Gold Flake Premium (Single)',
    price: 30.00,
    category: 'Ciggrates',
    createdAt: new Date('2026-06-14T15:30:00Z').toISOString()
  },
  {
    id: 'item-15',
    name: 'Marlboro Gold Box',
    price: 550.00,
    category: 'Ciggrates',
    createdAt: new Date('2026-06-15T16:30:00Z').toISOString()
  }
];

export const CONFECTIONERY_CATEGORIES = [
  'Sweet Suparis',
  'Cold Drinks',
  'Biscuits',
  'Candies',
  'Chips',
  'Ciggrates'
];
