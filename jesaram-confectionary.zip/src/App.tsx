import React, { useState, useEffect } from 'react';
import { ConfectioneryItem, Transaction, BluetoothPrinterState, ActiveTab } from './types';
import { INITIAL_CONFECTIONERY_ITEMS } from './initialData';
import { AdminInterface } from './components/AdminInterface';
import { SalesInterface } from './components/SalesInterface';
import { TransactionsInterface } from './components/TransactionsInterface';
import { PrinterInterface, playPrintSound } from './components/PrinterInterface';
import { ShoppingBag, Settings, History, Printer, Wifi, Clock, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<ActiveTab>('sales');

  // Offline Database storage states
  const [items, setItems] = useState<ConfectioneryItem[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Bluetooth printer state shared globally
  const [printerState, setPrinterState] = useState<BluetoothPrinterState>({
    isConnected: false,
    isConnecting: false,
    deviceName: null,
    error: null,
    logs: [
      `[${new Date().toLocaleTimeString()}] Thermal printer system booted.`,
      `[${new Date().toLocaleTimeString()}] Waiting for connection request...`
    ]
  });

  // Clock display state
  const [currentTime, setCurrentTime] = useState(new Date());

  // 1. Initial Database Seed on Startup
  useEffect(() => {
    // Load Confectionery Items
    const storedItems = localStorage.getItem('confectionery_items');
    const hasOldCategories = storedItems && (
      storedItems.includes('Cupcakes & Muffins') || 
      storedItems.includes('Chocolates & Truffles') || 
      storedItems.includes('Pastries & Cakes')
    );

    if (storedItems && !hasOldCategories) {
      setItems(JSON.parse(storedItems));
    } else {
      setItems(INITIAL_CONFECTIONERY_ITEMS);
      localStorage.setItem('confectionery_items', JSON.stringify(INITIAL_CONFECTIONERY_ITEMS));
    }

    // Load Transactions
    const storedTx = localStorage.getItem('confectionery_transactions');
    if (storedTx) {
      setTransactions(JSON.parse(storedTx));
    }

    // Tick the clock every second
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // 2. Database Action handlers
  const handleAddItem = (newItem: Omit<ConfectioneryItem, 'id' | 'createdAt'>) => {
    const id = `item-${Date.now()}`;
    const fullItem: ConfectioneryItem = {
      ...newItem,
      id,
      createdAt: new Date().toISOString()
    };
    
    setItems(prev => {
      const updated = [...prev, fullItem];
      localStorage.setItem('confectionery_items', JSON.stringify(updated));
      return updated;
    });

    setPrinterState(p => ({
      ...p,
      logs: [...p.logs, `[${new Date().toLocaleTimeString()}] DB_LOG: Added item "${fullItem.name}" @ Rs. ${fullItem.price.toFixed(2)}`]
    }));
  };

  const handleUpdateItem = (id: string, updatedFields: Partial<ConfectioneryItem>) => {
    setItems(prev => {
      const updated = prev.map(item => item.id === id ? { ...item, ...updatedFields } : item);
      localStorage.setItem('confectionery_items', JSON.stringify(updated));
      return updated;
    });

    const item = items.find(i => i.id === id);
    if (item) {
      setPrinterState(p => ({
        ...p,
        logs: [...p.logs, `[${new Date().toLocaleTimeString()}] DB_LOG: Edited item "${item.name}"`]
      }));
    }
  };

  const handleDeleteItem = (id: string) => {
    const item = items.find(i => i.id === id);
    setItems(prev => {
      const updated = prev.filter(item => item.id !== id);
      localStorage.setItem('confectionery_items', JSON.stringify(updated));
      return updated;
    });

    if (item) {
      setPrinterState(p => ({
        ...p,
        logs: [...p.logs, `[${new Date().toLocaleTimeString()}] DB_LOG: Removed item "${item.name}"`]
      }));
    }
  };

  // Bulk pricing adjuster
  const handleBulkAdjust = (
    adjustmentType: 'increase' | 'decrease',
    amountType: 'percent' | 'flat',
    value: number,
    category: string | 'all'
  ) => {
    setItems(prev => {
      const updated = prev.map(item => {
        if (category !== 'all' && item.category !== category) return item;

        let newPrice = item.price;
        if (amountType === 'percent') {
          const multiplier = value / 100;
          if (adjustmentType === 'increase') {
            newPrice = item.price * (1 + multiplier);
          } else {
            newPrice = item.price * (1 - multiplier);
          }
        } else {
          if (adjustmentType === 'increase') {
            newPrice = item.price + value;
          } else {
            newPrice = item.price - value;
          }
        }

        // Avoid sub-zero prices
        if (newPrice < 1.00) newPrice = 1.00;

        // Round to nearest whole rupee (Rs. 1)
        newPrice = Math.round(newPrice);

        return { ...item, price: newPrice };
      });

      localStorage.setItem('confectionery_items', JSON.stringify(updated));
      return updated;
    });

    setPrinterState(p => ({
      ...p,
      logs: [
        ...p.logs,
        `[${new Date().toLocaleTimeString()}] DB_LOG: Bulk adjust applied (${adjustmentType === 'increase' ? '+' : '-'}${value}${amountType === 'percent' ? '%' : ' Rs.'} on ${category})`
      ]
    }));
  };

  // Save transaction offline
  const handleSaveTransaction = (txData: Omit<Transaction, 'id' | 'billNumber' | 'dateTime'>): Transaction => {
    const totalTransactionsCount = transactions.length;
    
    // Create clean invoice number
    const dateStamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const billNumber = `JC-${dateStamp}-${String(totalTransactionsCount + 1).padStart(4, '0')}`;
    
    const fullTransaction: Transaction = {
      ...txData,
      id: `tx-${Date.now()}`,
      billNumber,
      dateTime: new Date().toISOString()
    };

    setTransactions(prev => {
      const updated = [fullTransaction, ...prev];
      localStorage.setItem('confectionery_transactions', JSON.stringify(updated));
      return updated;
    });

    return fullTransaction;
  };

  // Reprint Receipt Dispatcher
  const handlePrintReceipt = (tx: Transaction) => {
    setPrinterState(prev => {
      const logs = [...prev.logs];
      logs.push(`[${new Date().toLocaleTimeString()}] Re-print dispatch: Bill #${tx.billNumber}`);
      logs.push(`[${new Date().toLocaleTimeString()}] Raw bytes queue: 0x1B 0x69 (Paper Cut)`);
      return {
        ...prev,
        logs
      };
    });
  };

  // Print test receipt
  const handlePrintTest = () => {
    const formattedTime = new Date().toLocaleTimeString();
    playPrintSound();
    setPrinterState(prev => {
      const logs = [...prev.logs];
      logs.push(`[${formattedTime}] -- TEST RECEIPT QUEUE --`);
      logs.push(`[${formattedTime}] Text packet: "JESARAM CONFECTIONARY POS SYSTEM WORKING"`);
      logs.push(`[${formattedTime}] Text packet: "Self Test Completed."`);
      logs.push(`[${formattedTime}] Feed spacing: 3 lines`);
      logs.push(`[${formattedTime}] Status code: OK`);
      return { ...prev, logs };
    });
  };

  return (
    <div className="min-h-screen bg-bakery-50/50 flex flex-col justify-between py-6 px-4 font-sans antialiased text-cocoa-800">
      
      {/* Elegantly framed tablet/mobile display container for desktop */}
      <div className="w-full max-w-4xl mx-auto bg-bakery-50/20 md:shadow-xl md:border md:border-bakery-200/60 md:rounded-[40px] overflow-hidden flex flex-col h-[85vh] min-h-[640px] max-h-[900px] relative">
        
        {/* Device camera notch mock header for that modern premium hardware-integration aesthetic */}
        <div className="hidden md:flex bg-cocoa-900 h-6 text-white items-center justify-between px-8 text-[10px] tracking-wide select-none">
          <div className="flex items-center space-x-1.5 font-semibold">
            <Clock className="w-3.5 h-3.5 text-bakery-400" />
            <span className="font-mono text-bakery-100">{currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          
          {/* Notch spacer */}
          <div className="w-24 h-4.5 bg-cocoa-950 rounded-b-xl border-x border-cocoa-800"></div>
          
          <div className="flex items-center space-x-2">
            <span className="inline-flex items-center text-emerald-400 text-[9px] font-bold">
              <Wifi className="w-3.5 h-3.5 mr-1" />
              OFFLINE SECURE DB
            </span>
          </div>
        </div>

        {/* Primary Shop Header Branding bar */}
        <header className="bg-white px-6 py-4 border-b border-bakery-100 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-2xl bg-rose-candy-100 flex items-center justify-center text-rose-candy-600">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-display font-black text-cocoa-900 tracking-tight text-sm sm:text-base leading-tight">
                Jesaram Confectionary
              </h1>
              <p className="text-[10px] text-cocoa-500 font-sans tracking-wide">
                Mobile Point-of-Sale Terminal
              </p>
            </div>
          </div>

          <div className="flex space-x-2">
            {/* Quick status dots for physical integration verification */}
            <div className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-[10px] font-semibold border ${
              printerState.isConnected ? 'bg-emerald-50 border-emerald-100 text-emerald-700' : 'bg-cocoa-50 border-cocoa-100 text-cocoa-500'
            }`}>
              <Printer className="w-3.5 h-3.5" />
              <span>{printerState.isConnected ? 'Printer On' : 'Printer Off'}</span>
            </div>
          </div>
        </header>

        {/* Dynamic, Scrollable Content Panel */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 bg-bakery-50/30">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.15, ease: 'easeOut' }}
              className="h-full"
            >
              {activeTab === 'sales' && (
                <SalesInterface
                  items={items}
                  printerState={printerState}
                  setPrinterState={setPrinterState}
                  onSaveTransaction={handleSaveTransaction}
                />
              )}
              {activeTab === 'admin' && (
                <AdminInterface
                  items={items}
                  onAddItem={handleAddItem}
                  onUpdateItem={handleUpdateItem}
                  onDeleteItem={handleDeleteItem}
                  onBulkAdjust={handleBulkAdjust}
                />
              )}
              {activeTab === 'transactions' && (
                <TransactionsInterface
                  transactions={transactions}
                  onClearHistory={() => {
                    if (window.confirm('Are you sure you want to clear all offline sales history? This cannot be undone.')) {
                      setTransactions([]);
                      localStorage.removeItem('confectionery_transactions');
                    }
                  }}
                  onPrintReceipt={handlePrintReceipt}
                />
              )}
              {activeTab === 'printer' && (
                <PrinterInterface
                  printerState={printerState}
                  setPrinterState={setPrinterState}
                  onPrintTest={handlePrintTest}
                  lastTransaction={transactions[0] || null}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* iOS-styled bottom navigation dock */}
        <nav className="bg-white border-t border-bakery-100 px-4 py-2 flex items-center justify-around shrink-0 select-none">
          {/* Sales Interface tab */}
          <button
            onClick={() => setActiveTab('sales')}
            className={`flex flex-col items-center py-1.5 px-3 rounded-2xl transition-all ${
              activeTab === 'sales' ? 'text-rose-candy-500 font-bold scale-105' : 'text-cocoa-400 hover:text-cocoa-700'
            }`}
          >
            <ShoppingBag className="w-5.5 h-5.5" />
            <span className="text-[9px] mt-1 font-display uppercase tracking-widest font-semibold">Sales</span>
          </button>

          {/* Admin Interface tab */}
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex flex-col items-center py-1.5 px-3 rounded-2xl transition-all ${
              activeTab === 'admin' ? 'text-rose-candy-500 font-bold scale-105' : 'text-cocoa-400 hover:text-cocoa-700'
            }`}
          >
            <Settings className="w-5.5 h-5.5" />
            <span className="text-[9px] mt-1 font-display uppercase tracking-widest font-semibold">Admin</span>
          </button>

          {/* Transactions Interface tab */}
          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex flex-col items-center py-1.5 px-3 rounded-2xl transition-all ${
              activeTab === 'transactions' ? 'text-rose-candy-500 font-bold scale-105' : 'text-cocoa-400 hover:text-cocoa-700'
            }`}
          >
            <History className="w-5.5 h-5.5" />
            <span className="text-[9px] mt-1 font-display uppercase tracking-widest font-semibold">Log</span>
          </button>

          {/* Printer configuration tab */}
          <button
            onClick={() => setActiveTab('printer')}
            className={`flex flex-col items-center py-1.5 px-3 rounded-2xl transition-all ${
              activeTab === 'printer' ? 'text-rose-candy-500 font-bold scale-105' : 'text-cocoa-400 hover:text-cocoa-700'
            }`}
          >
            <Printer className="w-5.5 h-5.5" />
            <span className="text-[9px] mt-1 font-display uppercase tracking-widest font-semibold">Printer</span>
          </button>
        </nav>

      </div>

      {/* Humble aesthetic signature bottom margin copyright credit */}
      <footer className="text-center text-[10px] text-cocoa-400/80 mt-4 tracking-wider select-none">
        JESARAM CONFECTIONARY • SECURE OFFLINE POS TERMINAL
      </footer>

    </div>
  );
}
