import React, { useState, useRef } from 'react';
import { ConfectioneryItem, CartItem, Transaction, BluetoothPrinterState } from '../types';
import { CONFECTIONERY_CATEGORIES } from '../initialData';
import { Search, ShoppingBag, Plus, Minus, CreditCard, ChevronRight, CheckCircle, FileText, Download, Printer, User, DollarSign, X, ArrowRight, Sparkles, Image } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import { playPrintSound } from './PrinterInterface';

interface SalesInterfaceProps {
  items: ConfectioneryItem[];
  printerState: BluetoothPrinterState;
  setPrinterState: React.Dispatch<React.SetStateAction<BluetoothPrinterState>>;
  onSaveTransaction: (transaction: Omit<Transaction, 'id' | 'billNumber' | 'dateTime'>) => Transaction;
}

export const SalesInterface: React.FC<SalesInterfaceProps> = ({
  items,
  printerState,
  setPrinterState,
  onSaveTransaction
}) => {
  // Navigation & filtering states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | 'All'>('All');
  
  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<Transaction['paymentMethod']>('Cash');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Completed Receipt Overlay State
  const [completedOrder, setCompletedOrder] = useState<Transaction | null>(null);

  // Hidden canvas ref for generating JPEGs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Calculations
  const cartSubtotal = cart.reduce((acc, curr) => acc + (curr.item.price * curr.quantity), 0);
  const taxRate = 0.05; // 5% Sweetness Tax
  const cartTax = cartSubtotal * taxRate;
  const cartTotal = cartSubtotal + cartTax;

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Quantity updates
  const updateQuantity = (item: ConfectioneryItem, increment: number) => {
    setCart(prevCart => {
      const existingIdx = prevCart.findIndex(cartItem => cartItem.item.id === item.id);
      
      if (existingIdx > -1) {
        const updatedCart = [...prevCart];
        const newQty = updatedCart[existingIdx].quantity + increment;
        
        if (newQty <= 0) {
          updatedCart.splice(existingIdx, 1);
        } else {
          updatedCart[existingIdx] = { ...updatedCart[existingIdx], quantity: newQty };
        }
        return updatedCart;
      } else if (increment > 0) {
        return [...prevCart, { item, quantity: 1 }];
      }
      return prevCart;
    });
  };

  const getCartQuantity = (itemId: string): number => {
    const found = cart.find(cartItem => cartItem.item.id === itemId);
    return found ? found.quantity : 0;
  };

  const clearCart = () => {
    setCart([]);
    setCustomerName('');
    setPaymentMethod('Cash');
  };

  // 1. Generate and Download PDF using jsPDF
  const downloadPDFReceipt = (tx: Transaction) => {
    try {
      const doc = new jsPDF({
        unit: 'mm',
        format: [80, 180] // Receipt Roll style
      });

      doc.setFont('courier', 'bold');
      doc.setFontSize(12);
      doc.text('JESARAM CONFECTIONARY', 40, 12, { align: 'center' });
      
      doc.setFont('courier', 'normal');
      doc.setFontSize(8);
      doc.text('M.A. Jinnah Road, Karachi', 40, 17, { align: 'center' });
      doc.text('Tel: +92-21-3456789', 40, 21, { align: 'center' });
      
      doc.text('-'.repeat(35), 40, 25, { align: 'center' });
      
      // Invoice Details
      doc.setFont('courier', 'bold');
      doc.text(`BILL NO : ${tx.billNumber}`, 10, 30);
      doc.setFont('courier', 'normal');
      doc.text(`DATE    : ${new Date(tx.dateTime).toLocaleString()}`, 10, 34);
      doc.text(`CASHIER : SWEETS OPERATOR`, 10, 38);
      if (tx.customerName) {
        doc.text(`CUSTOMER: ${tx.customerName.toUpperCase()}`, 10, 42);
      }

      doc.text('-'.repeat(35), 40, 46, { align: 'center' });

      // Headers
      doc.text('QTY  ITEM                      TOTAL', 10, 50);
      doc.text('-'.repeat(35), 40, 53, { align: 'center' });

      // Items
      let y = 57;
      tx.items.forEach(cartItem => {
        const qtyStr = cartItem.quantity.toString().padEnd(4);
        
        // Truncate name if too long
        let nameStr = cartItem.item.name;
        if (nameStr.length > 20) nameStr = nameStr.substring(0, 18) + '..';
        nameStr = nameStr.padEnd(20);

        const totalStr = `Rs.${(cartItem.item.price * cartItem.quantity).toFixed(0)}`.padStart(11);
        doc.text(`${qtyStr}${nameStr}${totalStr}`, 10, y);
        y += 4.5;
      });

      doc.text('-'.repeat(35), 40, y, { align: 'center' });
      y += 4.5;

      // Totals
      const subtotal = tx.items.reduce((acc, c) => acc + (c.item.price * c.quantity), 0);
      const taxVal = subtotal * 0.05;
      doc.text(`SUBTOTAL:`.padEnd(20) + `Rs.${subtotal.toFixed(0)}`.padStart(12), 10, y);
      y += 4;
      doc.text(`SWEET TAX (5%):`.padEnd(20) + `Rs.${taxVal.toFixed(0)}`.padStart(12), 10, y);
      y += 4.5;
      doc.setFont('courier', 'bold');
      doc.text(`NET TOTAL:`.padEnd(20) + `Rs.${tx.total.toFixed(0)}`.padStart(12), 10, y);
      y += 5;

      doc.setFont('courier', 'normal');
      doc.text('-'.repeat(35), 40, y, { align: 'center' });
      y += 4.5;

      doc.text(`PAYMENT: ${tx.paymentMethod.toUpperCase()}`, 10, y);
      y += 6;

      doc.setFont('courier', 'italic');
      doc.setFontSize(7);
      doc.text('Thank you for making your day sweeter! ♥', 40, y, { align: 'center' });
      y += 4;
      doc.text('Visit again soon!', 40, y, { align: 'center' });

      // Save document
      doc.save(`JesaramReceipt_${tx.billNumber}.pdf`);
    } catch (err) {
      console.error('Failed to generate PDF', err);
    }
  };

  // 2. Generate and Download JPG using HTML5 Canvas
  const downloadJPGReceipt = (tx: Transaction) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Dimensions: 400px width, dynamic height
    const itemHeight = tx.items.length * 28;
    const canvasHeight = 440 + itemHeight;
    
    canvas.width = 400;
    canvas.height = canvasHeight;

    // White receipt paper background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 400, canvasHeight);

    // Subtle receipt thermal paper margins / shadow effect
    ctx.fillStyle = '#f5e3cc'; // warm creamy brand lines
    ctx.fillRect(0, 0, 400, 12);
    ctx.fillRect(0, canvasHeight - 12, 400, 12);

    // Text configuration
    ctx.fillStyle = '#292524'; // rich charcoal cocoa
    ctx.textAlign = 'center';

    // Store Logo
    ctx.font = 'bold 22px "Outfit", sans-serif';
    ctx.fillText('JESARAM CONFECTIONARY', 200, 50);

    ctx.font = '13px "Inter", sans-serif';
    ctx.fillStyle = '#57534e';
    ctx.fillText('M.A. Jinnah Road, Karachi', 200, 75);
    ctx.fillText('Tel: +92-21-3456789', 200, 95);

    // Divider Line
    ctx.strokeStyle = '#d6d3d1';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(30, 115);
    ctx.lineTo(370, 115);
    ctx.stroke();

    // Bill metadata
    ctx.textAlign = 'left';
    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#1c1917';
    ctx.fillText(`BILL NO: ${tx.billNumber}`, 40, 140);
    ctx.font = '12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#57534e';
    ctx.fillText(`DATE: ${new Date(tx.dateTime).toLocaleString()}`, 40, 160);
    ctx.fillText(`PAY: ${tx.paymentMethod}`, 40, 180);
    if (tx.customerName) {
      ctx.fillText(`CUSTOMER: ${tx.customerName}`, 40, 200);
    }

    // Divider Line
    ctx.beginPath();
    ctx.moveTo(30, 215);
    ctx.lineTo(370, 215);
    ctx.stroke();

    // Table Header
    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#1c1917';
    ctx.fillText('QTY', 40, 235);
    ctx.fillText('ITEM NAME', 100, 235);
    ctx.textAlign = 'right';
    ctx.fillText('TOTAL', 360, 235);

    // Table Items
    let currentY = 265;
    ctx.font = '12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#292524';
    tx.items.forEach(cartItem => {
      ctx.textAlign = 'left';
      ctx.fillText(cartItem.quantity.toString(), 40, currentY);
      
      let name = cartItem.item.name;
      if (name.length > 20) name = name.substring(0, 18) + '...';
      ctx.fillText(name, 100, currentY);

      ctx.textAlign = 'right';
      ctx.fillText(`Rs. ${(cartItem.item.price * cartItem.quantity).toFixed(0)}`, 360, currentY);
      
      currentY += 28;
    });

    // Divider Line
    ctx.beginPath();
    ctx.moveTo(30, currentY);
    ctx.lineTo(370, currentY);
    ctx.stroke();
    currentY += 30;

    // Totals calculations
    const subtotal = tx.items.reduce((acc, c) => acc + (c.item.price * c.quantity), 0);
    const taxVal = subtotal * 0.05;
    
    ctx.textAlign = 'left';
    ctx.fillStyle = '#57534e';
    ctx.fillText('Subtotal:', 100, currentY);
    ctx.textAlign = 'right';
    ctx.fillText(`Rs. ${subtotal.toFixed(0)}`, 360, currentY);
    currentY += 24;

    ctx.textAlign = 'left';
    ctx.fillText('Sweetness Tax (5%):', 100, currentY);
    ctx.textAlign = 'right';
    ctx.fillText(`Rs. ${taxVal.toFixed(0)}`, 360, currentY);
    currentY += 28;

    ctx.textAlign = 'left';
    ctx.font = 'bold 15px "JetBrains Mono", monospace';
    ctx.fillStyle = '#1c1917';
    ctx.fillText('NET TOTAL:', 100, currentY);
    ctx.textAlign = 'right';
    ctx.fillText(`Rs. ${tx.total.toFixed(0)}`, 360, currentY);
    currentY += 35;

    // Footer message
    ctx.textAlign = 'center';
    ctx.font = 'italic 12px "Inter", sans-serif';
    ctx.fillStyle = '#ff6e85'; // sweet rose
    ctx.fillText('Thank you for making your day sweeter! ♥', 200, currentY);
    ctx.font = '11px "Inter", sans-serif';
    ctx.fillStyle = '#a8a29e';
    ctx.fillText('Visit us again at Jesaram Confectionary', 200, currentY + 20);

    // Download JPG
    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      const link = document.createElement('a');
      link.download = `JesaramReceipt_${tx.billNumber}.jpg`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to export canvas to JPG', err);
    }
  };

  // Checkout Handler
  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    // Save transaction locally
    const tx = onSaveTransaction({
      items: cart,
      total: cartTotal,
      customerName: customerName.trim() || undefined,
      paymentMethod
    });

    setCompletedOrder(tx);
    setIsCheckoutOpen(false);

    // Trigger printing simulator automatically
    triggerBluetoothPrinting(tx);
  };

  // Trigger simulated Bluetooth printing logs & audio
  const triggerBluetoothPrinting = (tx: Transaction) => {
    const formattedDate = new Date(tx.dateTime).toLocaleTimeString();
    
    // Play realistic mechanical thermal paper whirr sound
    playPrintSound();

    setPrinterState(prev => {
      const logs = [...prev.logs];
      logs.push(`[${formattedDate}] -- INCOMING PRINT REQUEST --`);
      logs.push(`[${formattedDate}] Sending job for Bill #${tx.billNumber}`);
      logs.push(`[${formattedDate}] Raw command packet sent: 0x1B 0x40 (ESC @ Initialize)`);
      logs.push(`[${formattedDate}] Format: Width 58mm, Density High`);
      logs.push(`[${formattedDate}] Header bytes: Center text, 2.0x height`);
      logs.push(`[${formattedDate}] Printing ${tx.items.length} items to printhead array...`);
      logs.push(`[${formattedDate}] ESC/POS print job successfully finished!`);
      
      return {
        ...prev,
        logs
      };
    });
  };

  return (
    <div className="relative">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Products Grid Column (8 cols on desktop) */}
        <div className="lg:col-span-8 space-y-6">
          {/* Search and Category navigation */}
          <div className="space-y-4">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-4 top-3.5 text-cocoa-400" />
              <input
                type="text"
                placeholder="Search confectionery items..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-white rounded-2xl border border-bakery-200 text-cocoa-800 text-sm focus:outline-none focus:ring-2 focus:ring-bakery-400 font-sans"
              />
            </div>

            {/* Categories filter */}
            <div className="flex space-x-2 overflow-x-auto pb-1 scrollbar-none">
              <button
                onClick={() => setSelectedCategory('All')}
                className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all border ${
                  selectedCategory === 'All'
                    ? 'bg-rose-candy-500 border-rose-candy-500 text-white shadow-sm'
                    : 'bg-white border-bakery-200 text-cocoa-600 hover:bg-bakery-50'
                }`}
              >
                All Items
              </button>
              {CONFECTIONERY_CATEGORIES.map(category => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all border ${
                    selectedCategory === category
                      ? 'bg-rose-candy-500 border-rose-candy-500 text-white shadow-sm'
                      : 'bg-white border-bakery-200 text-cocoa-600 hover:bg-bakery-50'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Items Display Grid */}
          {filteredItems.length === 0 ? (
            <div className="p-12 text-center text-cocoa-400 bg-white rounded-3xl border border-bakery-100">
              <Sparkles className="w-8 h-8 mx-auto text-bakery-300 mb-2" />
              <p className="text-xs font-semibold">No items match your query.</p>
              <p className="text-xxs text-cocoa-500">Add some items in the Admin screen!</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
              {filteredItems.map(item => {
                const qty = getCartQuantity(item.id);
                return (
                  <motion.div
                    whileTap={{ scale: 0.98 }}
                    key={item.id}
                    className={`bg-white p-4 rounded-3xl border transition-all flex flex-col justify-between h-36 ${
                      qty > 0 ? 'border-rose-candy-300 ring-1 ring-rose-candy-200' : 'border-bakery-100'
                    }`}
                  >
                    <div className="space-y-0.5">
                      <span className="text-[10px] text-bakery-500 font-semibold tracking-wide uppercase block">
                        {item.category.split(' & ')[0]}
                      </span>
                      <h4 className="font-display font-bold text-cocoa-800 text-xs sm:text-sm line-clamp-2 leading-snug">
                        {item.name}
                      </h4>
                    </div>

                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-bakery-50">
                      <span className="font-sans font-bold text-cocoa-900 text-sm">
                        Rs. {item.price.toLocaleString()}
                      </span>

                      {qty > 0 ? (
                        <div className="flex items-center bg-rose-candy-50 border border-rose-candy-100 rounded-full py-0.5 px-1.5 space-x-2">
                          <button
                            onClick={() => updateQuantity(item, -1)}
                            className="p-1 text-rose-candy-600 hover:bg-rose-candy-100 rounded-full transition-colors"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="text-xs font-bold text-rose-candy-800 font-mono">{qty}</span>
                          <button
                            onClick={() => updateQuantity(item, 1)}
                            className="p-1 text-rose-candy-600 hover:bg-rose-candy-100 rounded-full transition-colors"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => updateQuantity(item, 1)}
                          className="p-1.5 bg-bakery-100 hover:bg-bakery-200 text-cocoa-700 rounded-full transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>

        {/* Checkout Cart Column (4 cols on desktop) */}
        <div className="lg:col-span-4 bg-white rounded-3xl p-5 shadow-sm border border-bakery-100 sticky top-4 self-start space-y-5">
          <div className="flex justify-between items-center pb-3 border-b border-bakery-100">
            <h3 className="font-display font-bold text-cocoa-800 text-sm uppercase tracking-wider flex items-center">
              <ShoppingBag className="w-4.5 h-4.5 mr-1.5 text-rose-candy-500" />
              Active Basket
            </h3>
            {cart.length > 0 && (
              <button
                onClick={clearCart}
                className="text-xxs font-semibold text-rose-candy-500 hover:underline"
              >
                Clear Cart
              </button>
            )}
          </div>

          {cart.length === 0 ? (
            <div className="py-14 text-center text-cocoa-400 space-y-2 select-none">
              <ShoppingBag className="w-9 h-9 mx-auto text-bakery-200 stroke-[1.5]" />
              <p className="text-xs font-semibold text-cocoa-500">Cart is empty</p>
              <p className="text-xxs">Select candies or cakes to start serving a customer</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Items List in Cart */}
              <div className="max-h-52 overflow-y-auto space-y-2 pr-1">
                {cart.map(cartItem => (
                  <div key={cartItem.item.id} className="flex justify-between items-center text-xs p-1.5 bg-bakery-50/50 rounded-xl">
                    <div className="space-y-0.5 flex-1 pr-2">
                      <span className="font-medium text-cocoa-800 block line-clamp-1">{cartItem.item.name}</span>
                      <span className="text-xxs text-cocoa-500 font-mono">
                        {cartItem.quantity} x Rs. {cartItem.item.price.toFixed(0)}
                      </span>
                    </div>
                    <span className="font-semibold text-cocoa-900 font-mono">
                      Rs. {(cartItem.item.price * cartItem.quantity).toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>

              {/* Subtotal, tax, net total summary */}
              <div className="pt-3 border-t border-bakery-100 space-y-1.5 text-xs text-cocoa-600">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-mono">Rs. {cartSubtotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Sweetness Tax (5%):</span>
                  <span className="font-mono">Rs. {cartTax.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-dashed border-bakery-200 font-bold text-sm text-cocoa-900">
                  <span>Net Total:</span>
                  <span className="font-mono text-rose-candy-600">Rs. {cartTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                </div>
              </div>

              {/* Proceed Button */}
              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full bg-rose-candy-500 hover:bg-rose-candy-600 text-white font-semibold py-3 px-4 rounded-2xl text-xs flex items-center justify-center space-x-1.5 transition-transform active:scale-[0.98] shadow-md shadow-rose-candy-50"
              >
                <span>Proceed to Checkout</span>
                <ChevronRight className="w-4.5 h-4.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Checkout Sidebar/Drawer Overlay */}
      <AnimatePresence>
        {isCheckoutOpen && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xxs flex items-center justify-end z-50">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="bg-white h-full w-full max-w-md shadow-2xl p-6 flex flex-col justify-between border-l border-bakery-100"
            >
              <div className="space-y-6">
                <div className="flex justify-between items-center pb-3 border-b border-bakery-100">
                  <h3 className="font-display font-bold text-cocoa-800 text-base flex items-center">
                    <CreditCard className="w-5 h-5 mr-2 text-rose-candy-500" />
                    Complete Sweet Order
                  </h3>
                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    className="p-1.5 rounded-full hover:bg-cocoa-50 text-cocoa-400 hover:text-cocoa-700"
                  >
                    <X className="w-5.5 h-5.5" />
                  </button>
                </div>

                <form onSubmit={handleCheckoutSubmit} className="space-y-5">
                  {/* Customer details */}
                  <div className="space-y-1.5">
                    <label className="block text-xxs font-semibold text-cocoa-600 uppercase tracking-wide">
                      Customer Name (Optional)
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-cocoa-400 absolute left-3 top-3.5" />
                      <input
                        type="text"
                        placeholder="e.g. Alice Johnson"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full pl-9 pr-4 py-3 bg-cocoa-50 border border-bakery-100 rounded-xl text-xs text-cocoa-800 focus:outline-none focus:ring-1 focus:ring-bakery-400 font-sans"
                      />
                    </div>
                  </div>

                  {/* Payment Methods */}
                  <div className="space-y-2">
                    <label className="block text-xxs font-semibold text-cocoa-600 uppercase tracking-wide">
                      Payment Mode
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      {(['Cash', 'Card', 'UPI', 'Mobile'] as const).map(mode => (
                        <button
                          key={mode}
                          type="button"
                          onClick={() => setPaymentMethod(mode)}
                          className={`p-3 rounded-xl border text-xs font-semibold flex items-center justify-between ${
                            paymentMethod === mode
                              ? 'bg-rose-candy-50 border-rose-candy-400 text-rose-candy-800'
                              : 'bg-white border-bakery-200 text-cocoa-600 hover:bg-bakery-50'
                          }`}
                        >
                          <span>{mode}</span>
                          {paymentMethod === mode && <span className="w-2 h-2 rounded-full bg-rose-candy-500"></span>}
                        </button>
                      ))}
                    </div>
                  </div>
                </form>

                {/* Bill details */}
                <div className="p-4 bg-bakery-50 rounded-2xl border border-bakery-100 space-y-2.5">
                  <h4 className="text-xxs font-semibold text-cocoa-500 uppercase tracking-wide">Charge breakdown</h4>
                  <div className="space-y-1.5 text-xs text-cocoa-600 font-mono">
                    <div className="flex justify-between">
                      <span>Subtotal:</span>
                      <span>Rs. {cartSubtotal.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sweetness Tax (5%):</span>
                      <span>Rs. {cartTax.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                    <div className="flex justify-between font-bold text-sm text-cocoa-900 border-t border-dashed border-bakery-200 pt-2">
                      <span>Amount Due:</span>
                      <span className="text-rose-candy-600">Rs. {cartTotal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-bakery-100 space-y-2.5">
                <button
                  onClick={handleCheckoutSubmit}
                  className="w-full bg-rose-candy-500 hover:bg-rose-candy-600 text-white font-semibold py-4 rounded-2xl text-xs flex items-center justify-center space-x-2 transition-transform active:scale-[0.98] shadow-md shadow-rose-candy-100"
                >
                  <span>Checkout & Print Bill</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsCheckoutOpen(false)}
                  className="w-full border border-cocoa-200 hover:bg-cocoa-50 text-cocoa-600 font-semibold py-3.5 rounded-2xl text-xs"
                >
                  Go Back
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Completed Order Success Overlay containing Receipt Download and Mock Tear View */}
      <AnimatePresence>
        {completedOrder && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-3xl p-6 shadow-2xl border border-bakery-100 max-w-sm w-full space-y-6 max-h-[90vh] overflow-y-auto"
            >
              <div className="text-center space-y-2">
                <CheckCircle className="w-11 h-11 text-emerald-500 mx-auto bg-emerald-50 p-2 rounded-full" />
                <h3 className="font-display font-bold text-cocoa-900 text-base">Checkout Completed!</h3>
                <p className="text-xxs text-cocoa-500 leading-relaxed">
                  The sweets transaction has been saved offline and dispatched to the virtual receipt printer.
                </p>
              </div>

              {/* Paper receipt presentation simulation (Tear out look) */}
              <div className="bg-cocoa-50 border-2 border-dashed border-cocoa-200 rounded-2xl p-4 font-mono text-xxs text-cocoa-800 space-y-3 relative overflow-hidden shadow-inner">
                {/* Simulated printer paper gloss */}
                <div className="absolute top-0 right-0 w-16 h-16 bg-white/20 transform rotate-45 translate-x-8 -translate-y-8 pointer-events-none"></div>
                
                <div className="text-center font-bold">
                  <span className="block text-xs uppercase font-display font-black tracking-wide text-cocoa-900">Jesaram Confectionary</span>
                  <span className="text-[9px] text-cocoa-500 font-sans font-medium">M.A. Jinnah Road, Karachi</span>
                </div>

                <div className="border-t border-dashed border-cocoa-300 pt-2 space-y-0.5">
                  <div>Bill: #{completedOrder.billNumber}</div>
                  <div>Date: {new Date(completedOrder.dateTime).toLocaleTimeString()}</div>
                  {completedOrder.customerName && (
                    <div>Customer: {completedOrder.customerName}</div>
                  )}
                </div>

                <div className="border-t border-dashed border-cocoa-300 pt-2">
                  <div className="flex justify-between font-bold mb-1">
                    <span>QTY  ITEM</span>
                    <span>TOTAL</span>
                  </div>
                  <div className="space-y-1">
                    {completedOrder.items.map(i => (
                      <div key={i.item.id} className="flex justify-between">
                        <span>{i.quantity} x {i.item.name.substring(0, 15)}</span>
                        <span>Rs. {(i.item.price * i.quantity).toFixed(0)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border-t border-dashed border-cocoa-300 pt-2 space-y-1">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>Rs. {(completedOrder.total / 1.05).toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sweet Tax (5%):</span>
                    <span>Rs. {(completedOrder.total - (completedOrder.total / 1.05)).toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-cocoa-900 text-xs">
                    <span>Net Paid ({completedOrder.paymentMethod}):</span>
                    <span className="text-rose-candy-600">Rs. {completedOrder.total.toFixed(0)}</span>
                  </div>
                </div>

                <div className="text-center text-[9px] text-cocoa-500 pt-2 border-t border-dashed border-cocoa-300 italic">
                  Thank you for supporting our sweet shop! ♥
                </div>
              </div>

              {/* Action and download options */}
              <div className="space-y-2">
                <button
                  onClick={() => downloadPDFReceipt(completedOrder)}
                  className="w-full bg-cocoa-800 hover:bg-cocoa-900 text-white font-semibold py-3 px-4 rounded-2xl text-xs flex items-center justify-center space-x-2 transition-transform active:scale-[0.98] shadow-sm"
                >
                  <FileText className="w-4 h-4" />
                  <span>Download PDF Receipt</span>
                </button>
                <button
                  onClick={() => downloadJPGReceipt(completedOrder)}
                  className="w-full bg-bakery-100 hover:bg-bakery-200 text-cocoa-700 font-semibold py-3 px-4 rounded-2xl text-xs flex items-center justify-center space-x-2 transition-transform active:scale-[0.98]"
                >
                  <Image className="w-4 h-4" />
                  <span>Download JPEG Receipt</span>
                </button>
                <button
                  onClick={() => {
                    setCompletedOrder(null);
                    clearCart();
                  }}
                  className="w-full bg-rose-candy-500 hover:bg-rose-candy-600 text-white font-semibold py-3.5 rounded-2xl text-xs transition-transform active:scale-[0.98]"
                >
                  New Order
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Hidden Canvas used purely to generate/raster JPG Receipts on client-side */}
      <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
    </div>
  );
};
