import React, { useState } from 'react';
import { BluetoothPrinterState, Transaction } from '../types';
import { Printer, Wifi, WifiOff, RefreshCw, FileText, CheckCircle, Terminal, HelpCircle, Volume2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PrinterInterfaceProps {
  printerState: BluetoothPrinterState;
  setPrinterState: React.Dispatch<React.SetStateAction<BluetoothPrinterState>>;
  onPrintTest: () => void;
  lastTransaction: Transaction | null;
}

// Native audio synthesizer to recreate the nostalgic thermal printer sound!
export const playPrintSound = () => {
  try {
    const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContext) return;
    const ctx = new AudioContext();
    const duration = 1.6; // duration of the whirr

    // Create a series of pulsed whirring steps (simulating print head moving)
    for (let step = 0; step < 6; step++) {
      const startTime = ctx.currentTime + (step * 0.25);
      const stepDuration = 0.18;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      // High pitched stepper motor whistle
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(380 + (step % 2 ? 15 : 0), startTime);
      
      // Smooth volume fade for each pulse
      gain.gain.setValueAtTime(0.06, startTime);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + stepDuration);

      // Low rumble for mechanical movement
      const rumble = ctx.createOscillator();
      rumble.type = 'sawtooth';
      rumble.frequency.setValueAtTime(95, startTime);
      const rumbleGain = ctx.createGain();
      rumbleGain.gain.setValueAtTime(0.03, startTime);
      rumbleGain.gain.exponentialRampToValueAtTime(0.001, startTime + stepDuration);

      // Connect and trigger
      osc.connect(gain);
      rumble.connect(rumbleGain);
      
      gain.connect(ctx.destination);
      rumbleGain.connect(ctx.destination);

      osc.start(startTime);
      rumble.start(startTime);
      osc.stop(startTime + stepDuration);
      rumble.stop(startTime + stepDuration);
    }
  } catch (err) {
    console.warn("Web Audio API not allowed or supported by environment", err);
  }
};

export const PrinterInterface: React.FC<PrinterInterfaceProps> = ({
  printerState,
  setPrinterState,
  onPrintTest,
  lastTransaction
}) => {
  const [useBLE, setUseBLE] = useState<boolean>(false);
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>('58mm');
  const [showBluetoothHelp, setShowBluetoothHelp] = useState<boolean>(false);

  // Simulated device scanning
  const startScanningAndConnect = async () => {
    setPrinterState(prev => ({
      ...prev,
      isConnecting: true,
      error: null,
      logs: [...prev.logs, `[${new Date().toLocaleTimeString()}] Initializing Bluetooth printer search...`]
    }));

    if (useBLE && (navigator as any).bluetooth) {
      try {
        // Real Web Bluetooth API implementation
        const device = await (navigator as any).bluetooth.requestDevice({
          filters: [
            { namePrefix: 'Printer' },
            { namePrefix: 'PRINTER' },
            { namePrefix: 'PT-' },
            { namePrefix: 'MTP' }
          ],
          optionalServices: ['000018f0-0000-1000-8000-00805f9b34fb', '00001101-0000-1000-8000-00805f9b34fb']
        });

        setPrinterState(prev => ({
          ...prev,
          logs: [...prev.logs, `[${new Date().toLocaleTimeString()}] Device chosen: ${device.name}. Connecting...`]
        }));

        const server = await device.gatt?.connect();
        
        setPrinterState(prev => ({
          ...prev,
          isConnected: true,
          isConnecting: false,
          deviceName: device.name || 'BT Printer',
          logs: [...prev.logs, `[${new Date().toLocaleTimeString()}] Successfully connected to active BLE port of ${device.name}!`]
        }));

      } catch (err: any) {
        setPrinterState(prev => ({
          ...prev,
          isConnecting: false,
          error: err.message || 'Bluetooth connection cancelled or failed.',
          logs: [...prev.logs, `[${new Date().toLocaleTimeString()}] Connection error: ${err.message || 'User cancelled scanner'}`]
        }));
      }
    } else {
      // Elegant, fast simulation of high-quality connection
      setTimeout(() => {
        setPrinterState(prev => ({
          ...prev,
          isConnected: true,
          isConnecting: false,
          deviceName: 'Jesaram-Thermal PT-210',
          logs: [
            ...prev.logs,
            `[${new Date().toLocaleTimeString()}] BLE Scan discovered device: Jesaram-Thermal PT-210`,
            `[${new Date().toLocaleTimeString()}] Pairing PIN verified automatically...`,
            `[${new Date().toLocaleTimeString()}] Socket port open on SPP GATT profile UUID 18f0.`,
            `[${new Date().toLocaleTimeString()}] Printer status: Ready, Online (battery 85%)`
          ]
        }));
        playPrintSound();
      }, 1200);
    }
  };

  const disconnectPrinter = () => {
    const name = printerState.deviceName || 'Printer';
    setPrinterState(prev => ({
      ...prev,
      isConnected: false,
      deviceName: null,
      logs: [...prev.logs, `[${new Date().toLocaleTimeString()}] Disconnected from ${name}.`]
    }));
  };

  const clearLogs = () => {
    setPrinterState(prev => ({
      ...prev,
      logs: [`[${new Date().toLocaleTimeString()}] Log console cleared.`]
    }));
  };

  return (
    <div className="space-y-6">
      {/* Bluetooth Status Summary Card */}
      <div className="bg-white rounded-3xl p-6 shadow-sm border border-bakery-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`p-3 rounded-2xl ${printerState.isConnected ? 'bg-emerald-50 text-emerald-600' : 'bg-bakery-100 text-bakery-600'}`}>
              <Printer className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-display font-semibold text-cocoa-800 text-lg">Receipt Printer</h3>
              <p className="text-xs text-cocoa-500 font-sans">Connect a portable BT thermal printer</p>
            </div>
          </div>
          <div className="flex items-center">
            {printerState.isConnected ? (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                <Wifi className="w-3.5 h-3.5 mr-1" />
                Connected
              </span>
            ) : printerState.isConnecting ? (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800 animate-pulse">
                <RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" />
                Connecting
              </span>
            ) : (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-cocoa-100 text-cocoa-700">
                <WifiOff className="w-3.5 h-3.5 mr-1" />
                Offline
              </span>
            )}
          </div>
        </div>

        {/* Printer Details */}
        {printerState.isConnected && (
          <div className="mb-6 p-4 bg-bakery-50 rounded-2xl border border-bakery-100 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-cocoa-500">Device Name:</span>
              <span className="font-semibold text-cocoa-800">{printerState.deviceName}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-cocoa-500">Interface Type:</span>
              <span className="font-mono text-cocoa-700">Bluetooth SPP (BLE)</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-cocoa-500">Paper Width:</span>
              <span className="font-semibold text-cocoa-800">{paperWidth}</span>
            </div>
          </div>
        )}

        {/* Setup controls */}
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3.5 bg-cocoa-50 rounded-2xl border border-cocoa-100">
            <div className="space-y-0.5">
              <span className="text-sm font-medium text-cocoa-800 block">Use Native Web Bluetooth API</span>
              <span className="text-xxs text-cocoa-500">Allows real connection to physical BLE hardware</span>
            </div>
            <button
              onClick={() => setUseBLE(!useBLE)}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                useBLE ? 'bg-rose-candy-500' : 'bg-cocoa-300'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  useBLE ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex space-x-3">
            <button
              onClick={() => setPaperWidth(paperWidth === '58mm' ? '80mm' : '58mm')}
              className="flex-1 py-3 px-4 rounded-2xl border border-bakery-200 hover:bg-bakery-50 text-cocoa-700 text-xs font-semibold flex items-center justify-center space-x-2"
            >
              <span>Paper: {paperWidth}</span>
            </button>
            <button
              onClick={() => setShowBluetoothHelp(!showBluetoothHelp)}
              className="py-3 px-3 rounded-2xl border border-cocoa-200 hover:bg-cocoa-50 text-cocoa-600 text-xs font-semibold flex items-center justify-center"
              title="Connection help"
            >
              <HelpCircle className="w-5 h-5" />
            </button>
          </div>

          {showBluetoothHelp && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-xs text-amber-900 space-y-2"
            >
              <p className="font-semibold flex items-center">
                <AlertCircle className="w-4 h-4 mr-1.5 shrink-0" /> How Bluetooth Printer Connection Works:
              </p>
              <ul className="list-disc list-inside space-y-1 pl-1 text-xxs text-amber-800">
                <li><strong>Simulated Mode (Default)</strong>: Runs an advanced printer emulator below with authentic physical whistle sounds and instant paper feeding. Perfect for standard reviews!</li>
                <li><strong>Real Mode</strong>: Toggling Web Bluetooth will trigger the browser's pairing agent to query real portable POS printers. Needs HTTPS and browser BLE permissions enabled.</li>
              </ul>
            </motion.div>
          )}

          {printerState.error && (
            <div className="p-3.5 bg-rose-50 border border-rose-100 rounded-2xl flex items-start space-x-2.5 text-xs text-rose-800">
              <AlertCircle className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
              <span>{printerState.error}</span>
            </div>
          )}

          {printerState.isConnected ? (
            <div className="flex space-x-3">
              <button
                onClick={onPrintTest}
                className="flex-1 bg-bakery-600 text-white font-semibold py-3.5 px-4 rounded-2xl text-xs hover:bg-bakery-700 active:scale-[0.98] transition-transform shadow-sm flex items-center justify-center space-x-2"
              >
                <Volume2 className="w-4 h-4" />
                <span>Print Test Receipt</span>
              </button>
              <button
                onClick={disconnectPrinter}
                className="px-5 bg-rose-50 text-rose-600 font-semibold py-3.5 rounded-2xl text-xs hover:bg-rose-100 active:scale-[0.98] transition-all"
              >
                Disconnect
              </button>
            </div>
          ) : (
            <button
              onClick={startScanningAndConnect}
              disabled={printerState.isConnecting}
              className="w-full bg-rose-candy-500 text-white font-semibold py-4 rounded-2xl text-sm hover:bg-rose-candy-600 active:scale-[0.98] transition-transform shadow-md shadow-rose-candy-100 flex items-center justify-center space-x-2"
            >
              <Wifi className="w-5 h-5" />
              <span>{printerState.isConnecting ? 'Searching Printer...' : 'Search & Connect Printer'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Visual Bluetooth Printer Simulator Widget */}
      <div className="bg-cocoa-800 text-white rounded-3xl p-6 shadow-xl border border-cocoa-900 overflow-hidden relative">
        <div className="absolute top-3 right-3 flex space-x-1">
          <div className={`w-2 h-2 rounded-full ${printerState.isConnected ? 'bg-emerald-400 animate-ping' : 'bg-cocoa-600'}`}></div>
          <div className={`w-2 h-2 rounded-full ${printerState.isConnected ? 'bg-emerald-400' : 'bg-cocoa-600'}`}></div>
          <div className={`w-2 h-2 rounded-full bg-rose-400`}></div>
        </div>
        
        <h3 className="font-display font-bold text-sm tracking-widest text-bakery-300 uppercase mb-4 flex items-center">
          <Terminal className="w-4 h-4 mr-1.5" />
          Hardware Emulator Console
        </h3>

        {/* Paper roll representation */}
        <div className="relative mb-4 bg-cocoa-900 rounded-2xl p-4 border border-cocoa-700 font-mono text-xxs text-emerald-400 h-44 overflow-y-auto space-y-1 select-none">
          {printerState.logs.map((log, idx) => (
            <div key={idx} className="leading-tight break-all">
              {log.startsWith('[') ? (
                <span className="text-cocoa-400">{log}</span>
              ) : (
                <span className="text-emerald-300">{log}</span>
              )}
            </div>
          ))}
          {printerState.isConnecting && (
            <div className="text-amber-300 flex items-center">
              <RefreshCw className="w-3 h-3 mr-1 animate-spin" /> Scanning BLE frequencies...
            </div>
          )}
        </div>

        <div className="flex justify-between items-center text-xxs text-cocoa-400">
          <span>Speed: 90mm/s</span>
          <button 
            onClick={clearLogs}
            className="text-bakery-300 hover:underline"
          >
            Clear Console
          </button>
        </div>

        {/* Beautiful Physical Printer Graphic Representation */}
        <div className="mt-6 pt-4 border-t border-cocoa-700 flex flex-col items-center">
          <div className="w-44 h-10 bg-cocoa-950 rounded-t-xl relative border-t-2 border-x-2 border-cocoa-600 flex items-center justify-center">
            {/* Paper tear bar slot */}
            <div className="w-40 h-1.5 bg-black rounded-full relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-cocoa-800 to-transparent"></div>
            </div>
            {/* Status LEDs */}
            <div className="absolute left-4 bottom-1 flex space-x-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${printerState.isConnected ? 'bg-emerald-400' : 'bg-red-400'}`} title="Bluetooth LED"></span>
              <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse" title="Power LED"></span>
            </div>
          </div>
          
          <div className="w-48 h-5 bg-cocoa-900 rounded-b-xl shadow-lg border-b-4 border-x-2 border-cocoa-700 text-center flex items-center justify-center">
            <span className="text-[8px] font-sans font-bold tracking-widest text-cocoa-500 uppercase">PORTABLE THERMAL POS</span>
          </div>
        </div>
      </div>
    </div>
  );
};
