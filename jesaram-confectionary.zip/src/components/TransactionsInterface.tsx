import React, { useState, useRef } from 'react';
import { Transaction } from '../types';
import { Search, Calendar, CreditCard, ChevronDown, ChevronUp, FileText, Download, Printer, TrendingUp, DollarSign, ShoppingBag, Eye, Image, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { jsPDF } from 'jspdf';
import { playPrintSound } from './PrinterInterface';

interface TransactionsInterfaceProps {
  transactions: Transaction[];
  onClearHistory: () => void;
  onPrintReceipt: (tx: Transaction) => void;
}

export const TransactionsInterface: React.FC<TransactionsInterfaceProps> = ({
  transactions,
  onClearHistory,
  onPrintReceipt
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<string | 'All'>('All');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Hidden canvas ref for generating JPEGs on the fly
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Filtered transactions
  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = 
      tx.billNumber.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (tx.customerName && tx.customerName.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesPayment = paymentFilter === 'All' || tx.paymentMethod === paymentFilter;
    return matchesSearch && matchesPayment;
  }).sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime());

  // Statistics Calculations
  const totalRevenue = transactions.reduce((sum, tx) => sum + tx.total, 0);
  const totalOrders = transactions.length;
  const avgOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
  
  // Calculate top payment method
  const payCounts = transactions.reduce((acc, tx) => {
    acc[tx.paymentMethod] = (acc[tx.paymentMethod] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  let topPayment = 'None';
  let maxCount = 0;
  Object.entries(payCounts).forEach(([method, count]) => {
    const countNum = count as number;
    if (countNum > maxCount) {
      maxCount = countNum;
      topPayment = method;
    }
  });

  const toggleExpand = (id: string) => {
    setExpandedId(prev => (prev === id ? null : id));
  };

  // PDF Download Helper
  const downloadPDFReceipt = (tx: Transaction) => {
    try {
      const doc = new jsPDF({
        unit: 'mm',
        format: [80, 180]
      });

      doc.setFont('courier', 'bold');
      doc.setFontSize(12);
      doc.text('JESARAM CONFECTIONARY', 40, 12, { align: 'center' });
      
      doc.setFont('courier', 'normal');
      doc.setFontSize(8);
      doc.text('M.A. Jinnah Road, Karachi', 40, 17, { align: 'center' });
      doc.text('Tel: +92-21-3456789', 40, 21, { align: 'center' });
      doc.text('-'.repeat(35), 40, 25, { align: 'center' });
      
      doc.setFont('courier', 'bold');
      doc.text(`BILL NO : ${tx.billNumber}`, 10, 30);
      doc.setFont('courier', 'normal');
      doc.text(`DATE    : ${new Date(tx.dateTime).toLocaleString()}`, 10, 34);
      doc.text(`CASHIER : SWEETS OPERATOR`, 10, 38);
      if (tx.customerName) {
        doc.text(`CUSTOMER: ${tx.customerName.toUpperCase()}`, 10, 42);
      }

      doc.text('-'.repeat(35), 40, 46, { align: 'center' });
      doc.text('QTY  ITEM                      TOTAL', 10, 50);
      doc.text('-'.repeat(35), 40, 53, { align: 'center' });

      let y = 57;
      tx.items.forEach(cartItem => {
        const qtyStr = cartItem.quantity.toString().padEnd(4);
        let nameStr = cartItem.item.name;
        if (nameStr.length > 20) nameStr = nameStr.substring(0, 18) + '..';
        nameStr = nameStr.padEnd(20);
        const totalStr = `Rs.${(cartItem.item.price * cartItem.quantity).toFixed(0)}`.padStart(11);
        doc.text(`${qtyStr}${nameStr}${totalStr}`, 10, y);
        y += 4.5;
      });

      doc.text('-'.repeat(35), 40, y, { align: 'center' });
      y += 4.5;

      const subtotal = tx.items.reduce((acc, c) => acc + (c.item.price * c.quantity), 0);
      const taxVal = subtotal * 0.05;
      doc.text(`SUBTOTAL:`.padEnd(20) + `Rs.${subtotal.toFixed(0)}`.padStart(12), 10, y);
      y += 4;
      doc.text(`SWEET TAX (5%):`.padEnd(20) + `Rs.${taxVal.toFixed(0)}`.padStart(12), 10, y);
      y += 4.5;
      doc.setFont('courier', 'bold');
      doc.text(`NET TOTAL:`.padEnd(20) + `Rs.${tx.total.toFixed(0)}`.padStart(12), 10, y);
      y += 5;

      doc.setFont('courier', 'normal');
      doc.text('-'.repeat(35), 40, y, { align: 'center' });
      y += 4.5;

      doc.text(`PAYMENT: ${tx.paymentMethod.toUpperCase()}`, 10, y);
      y += 6;

      doc.setFont('courier', 'italic');
      doc.setFontSize(7);
      doc.text('Thank you for making your day sweeter! ♥', 40, y, { align: 'center' });
      y += 4;
      doc.text('Visit again soon!', 40, y, { align: 'center' });

      doc.save(`JesaramReceipt_${tx.billNumber}.pdf`);
    } catch (err) {
      console.error('Failed to generate PDF', err);
    }
  };

  // JPG Download Helper using HTML5 Canvas
  const downloadJPGReceipt = (tx: Transaction) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const itemHeight = tx.items.length * 28;
    const canvasHeight = 440 + itemHeight;
    
    canvas.width = 400;
    canvas.height = canvasHeight;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 400, canvasHeight);

    ctx.fillStyle = '#f5e3cc';
    ctx.fillRect(0, 0, 400, 12);
    ctx.fillRect(0, canvasHeight - 12, 400, 12);

    ctx.fillStyle = '#292524';
    ctx.textAlign = 'center';

    ctx.font = 'bold 22px "Outfit", sans-serif';
    ctx.fillText('JESARAM CONFECTIONARY', 200, 50);

    ctx.font = '13px "Inter", sans-serif';
    ctx.fillStyle = '#57534e';
    ctx.fillText('M.A. Jinnah Road, Karachi', 200, 75);
    ctx.fillText('Tel: +92-21-3456789', 200, 95);

    ctx.strokeStyle = '#d6d3d1';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 4]);
    ctx.beginPath();
    ctx.moveTo(30, 115);
    ctx.lineTo(370, 115);
    ctx.stroke();

    ctx.textAlign = 'left';
    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#1c1917';
    ctx.fillText(`BILL NO: ${tx.billNumber}`, 40, 140);
    ctx.font = '12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#57534e';
    ctx.fillText(`DATE: ${new Date(tx.dateTime).toLocaleString()}`, 40, 160);
    ctx.fillText(`PAY: ${tx.paymentMethod}`, 40, 180);
    if (tx.customerName) {
      ctx.fillText(`CUSTOMER: ${tx.customerName}`, 40, 200);
    }

    ctx.beginPath();
    ctx.moveTo(30, 215);
    ctx.lineTo(370, 215);
    ctx.stroke();

    ctx.font = 'bold 12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#1c1917';
    ctx.fillText('QTY', 40, 235);
    ctx.fillText('ITEM NAME', 100, 235);
    ctx.textAlign = 'right';
    ctx.fillText('TOTAL', 360, 235);

    let currentY = 265;
    ctx.font = '12px "JetBrains Mono", monospace';
    ctx.fillStyle = '#292524';
    tx.items.forEach(cartItem => {
      ctx.textAlign = 'left';
      ctx.fillText(cartItem.quantity.toString(), 40, currentY);
      
      let name = cartItem.item.name;
      if (name.length > 20) name = name.substring(0, 18) + '...';
      ctx.fillText(name, 100, currentY);

      ctx.textAlign = 'right';
      ctx.fillText(`Rs. ${(cartItem.item.price * cartItem.quantity).toFixed(0)}`, 360, currentY);
      
      currentY += 28;
    });

    ctx.beginPath();
    ctx.moveTo(30, currentY);
    ctx.lineTo(370, currentY);
    ctx.stroke();
    currentY += 30;

    const subtotal = tx.items.reduce((acc, c) => acc + (c.item.price * c.quantity), 0);
    const taxVal = subtotal * 0.05;
    
    ctx.textAlign = 'left';
    ctx.fillStyle = '#57534e';
    ctx.fillText('Subtotal:', 100, currentY);
    ctx.textAlign = 'right';
    ctx.fillText(`Rs. ${subtotal.toFixed(0)}`, 360, currentY);
    currentY += 24;

    ctx.textAlign = 'left';
    ctx.fillText('Sweetness Tax (5%):', 100, currentY);
    ctx.textAlign = 'right';
    ctx.fillText(`Rs. ${taxVal.toFixed(0)}`, 360, currentY);
    currentY += 28;

    ctx.textAlign = 'left';
    ctx.font = 'bold 15px "JetBrains Mono", monospace';
    ctx.fillStyle = '#1c1917';
    ctx.fillText('NET TOTAL:', 100, currentY);
    ctx.textAlign = 'right';
    ctx.fillText(`Rs. ${tx.total.toFixed(0)}`, 360, currentY);
    currentY += 35;

    ctx.textAlign = 'center';
    ctx.font = 'italic 12px "Inter", sans-serif';
    ctx.fillStyle = '#ff6e85';
    ctx.fillText('Thank you for making your day sweeter! ♥', 200, currentY);
    ctx.font = '11px "Inter", sans-serif';
    ctx.fillStyle = '#a8a29e';
    ctx.fillText('Visit us again at Jesaram Confectionary', 200, currentY + 20);

    try {
      const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      const link = document.createElement('a');
      link.download = `JesaramReceipt_${tx.billNumber}.jpg`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to export canvas to JPG', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Dashboard Analytics Header cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white p-4 rounded-3xl border border-bakery-100 shadow-xxs">
          <span className="text-[10px] font-semibold text-cocoa-500 uppercase tracking-wider block">Total Sales</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="font-display font-bold text-cocoa-900 text-lg">Rs. {totalRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-bakery-100 shadow-xxs">
          <span className="text-[10px] font-semibold text-cocoa-500 uppercase tracking-wider block">Bills Served</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="font-display font-bold text-cocoa-900 text-lg">{totalOrders}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-bakery-100 shadow-xxs">
          <span className="text-[10px] font-semibold text-cocoa-500 uppercase tracking-wider block">Avg Ticket</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="font-display font-bold text-cocoa-900 text-lg">Rs. {avgOrderValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-bakery-100 shadow-xxs">
          <span className="text-[10px] font-semibold text-cocoa-500 uppercase tracking-wider block">Top Channel</span>
          <div className="flex items-baseline space-x-1 mt-1">
            <span className="font-display font-bold text-rose-candy-500 text-lg">{topPayment}</span>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3.5 top-3.5 text-cocoa-400" />
          <input
            type="text"
            placeholder="Search by Bill # or customer..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-3.5 bg-white rounded-2xl border border-bakery-200 text-cocoa-800 text-sm focus:outline-none focus:ring-2 focus:ring-bakery-400 font-sans"
          />
        </div>

        <div className="flex space-x-2">
          <select
            value={paymentFilter}
            onChange={(e) => setPaymentFilter(e.target.value)}
            className="px-4 py-3 bg-white border border-bakery-200 rounded-2xl text-xs text-cocoa-700 font-semibold focus:outline-none"
          >
            <option value="all">All Channels</option>
            <option value="Cash">Cash Only</option>
            <option value="Card">Card Only</option>
            <option value="UPI">UPI Only</option>
            <option value="Mobile">Mobile Only</option>
          </select>

          {transactions.length > 0 && (
            <button
              onClick={onClearHistory}
              className="px-4 py-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-semibold text-xs rounded-2xl flex items-center space-x-1.5 transition-colors"
            >
              <Trash2 className="w-4 h-4" />
              <span>Reset Log</span>
            </button>
          )}
        </div>
      </div>

      {/* Transactions Table/List */}
      <div className="bg-white rounded-3xl shadow-sm border border-bakery-100 overflow-hidden">
        {filteredTransactions.length === 0 ? (
          <div className="p-14 text-center text-cocoa-400 space-y-2 select-none">
            <ShoppingBag className="w-8 h-8 mx-auto text-bakery-300" />
            <p className="text-xs font-semibold">No transactions recorded.</p>
            <p className="text-xxs">Checkout clients via the Sales interface to populate history.</p>
          </div>
        ) : (
          <div className="divide-y divide-bakery-100">
            {filteredTransactions.map(tx => {
              const isExpanded = expandedId === tx.id;
              const formattedTime = new Date(tx.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
              
              return (
                <div key={tx.id} className="transition-colors hover:bg-bakery-50/20">
                  {/* Collapsed Header Bar */}
                  <div 
                    onClick={() => toggleExpand(tx.id)}
                    className="p-4 flex items-center justify-between cursor-pointer select-none"
                  >
                    <div className="flex items-center space-x-3.5">
                      <div className="p-2 bg-cocoa-50 rounded-xl text-cocoa-600">
                        <CreditCard className="w-4 h-4" />
                      </div>
                      <div className="space-y-0.5">
                        <div className="flex items-center space-x-1.5">
                          <span className="font-mono font-bold text-cocoa-800 text-xs">{tx.billNumber}</span>
                          {tx.customerName && (
                            <span className="text-xxs px-2 py-0.5 rounded-full bg-bakery-100 text-cocoa-700 font-semibold">
                              {tx.customerName}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center space-x-2 text-xxs text-cocoa-500 font-sans">
                          <span>{formattedTime}</span>
                          <span>•</span>
                          <span>{tx.items.reduce((sum, item) => sum + item.quantity, 0)} sweets</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <span className="font-sans font-bold text-cocoa-900 text-sm block">Rs. {tx.total.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                        <span className="text-xxs text-cocoa-400 font-medium block">{tx.paymentMethod}</span>
                      </div>
                      {isExpanded ? <ChevronUp className="w-5 h-5 text-cocoa-400" /> : <ChevronDown className="w-5 h-5 text-cocoa-400" />}
                    </div>
                  </div>

                  {/* Expanded Transaction Drawer */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden bg-cocoa-50/50 border-t border-bakery-100"
                      >
                        <div className="p-5 space-y-4">
                          {/* Item lines */}
                          <div className="space-y-2">
                            <h4 className="text-xxs font-bold text-cocoa-500 uppercase tracking-wider">Itemized Breakdown</h4>
                            <div className="bg-white rounded-2xl border border-bakery-100 p-3.5 space-y-2">
                              {tx.items.map(cartItem => (
                                <div key={cartItem.item.id} className="flex justify-between items-center text-xs">
                                  <span className="text-cocoa-700">
                                    {cartItem.quantity} x {cartItem.item.name}
                                  </span>
                                  <span className="font-semibold text-cocoa-900 font-mono">
                                    Rs. {(cartItem.item.price * cartItem.quantity).toLocaleString()}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Action Bar */}
                          <div className="flex flex-col sm:flex-row gap-2 justify-between items-stretch sm:items-center pt-2">
                            <div className="flex space-x-1.5">
                              <button
                                onClick={() => downloadPDFReceipt(tx)}
                                className="flex-1 sm:flex-initial py-2 px-3.5 bg-white border border-cocoa-200 hover:bg-cocoa-50 rounded-xl text-xxs font-semibold text-cocoa-700 flex items-center justify-center space-x-1.5"
                              >
                                <FileText className="w-3.5 h-3.5" />
                                <span>PDF Bill</span>
                              </button>
                              
                              <button
                                onClick={() => downloadJPGReceipt(tx)}
                                className="flex-1 sm:flex-initial py-2 px-3.5 bg-white border border-cocoa-200 hover:bg-cocoa-50 rounded-xl text-xxs font-semibold text-cocoa-700 flex items-center justify-center space-x-1.5"
                              >
                                <Image className="w-3.5 h-3.5" />
                                <span>JPG Bill</span>
                              </button>
                            </div>

                            <button
                              onClick={() => {
                                onPrintReceipt(tx);
                                playPrintSound();
                              }}
                              className="py-2.5 px-4 bg-rose-candy-500 hover:bg-rose-candy-600 rounded-xl text-xxs font-bold text-white flex items-center justify-center space-x-1.5"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>Re-print Thermal Receipt</span>
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Hidden canvas for JPEG rendering */}
      <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
    </div>
  );
};
