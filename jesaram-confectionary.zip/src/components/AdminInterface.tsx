import React, { useState } from 'react';
import { ConfectioneryItem } from '../types';
import { CONFECTIONERY_CATEGORIES } from '../initialData';
import { Plus, Edit2, Trash2, Search, Percent, RefreshCw, Layers, Check, X, Tag, DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AdminInterfaceProps {
  items: ConfectioneryItem[];
  onAddItem: (item: Omit<ConfectioneryItem, 'id' | 'createdAt'>) => void;
  onUpdateItem: (id: string, updated: Partial<ConfectioneryItem>) => void;
  onDeleteItem: (id: string) => void;
  onBulkAdjust: (adjustmentType: 'increase' | 'decrease', amountType: 'percent' | 'flat', value: number, category: string | 'all') => void;
}

export const AdminInterface: React.FC<AdminInterfaceProps> = ({
  items,
  onAddItem,
  onUpdateItem,
  onDeleteItem,
  onBulkAdjust
}) => {
  // Local states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | 'All'>('All');
  
  // Create / Edit Form state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ConfectioneryItem | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    category: CONFECTIONERY_CATEGORIES[0]
  });

  // Bulk Adjustment panel state
  const [isAdjusterOpen, setIsAdjusterOpen] = useState(false);
  const [adjustConfig, setAdjustConfig] = useState({
    type: 'increase' as 'increase' | 'decrease',
    amountType: 'percent' as 'percent' | 'flat',
    value: '',
    category: 'all' as string
  });
  const [showAdjustSuccess, setShowAdjustSuccess] = useState(false);

  // Filter items
  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.price) return;

    const priceNum = parseFloat(formData.price);
    if (isNaN(priceNum) || priceNum < 0) return;

    if (editingItem) {
      onUpdateItem(editingItem.id, {
        name: formData.name.trim(),
        price: priceNum,
        category: formData.category
      });
    } else {
      onAddItem({
        name: formData.name.trim(),
        price: priceNum,
        category: formData.category
      });
    }

    // Reset Form
    setFormData({ name: '', price: '', category: CONFECTIONERY_CATEGORIES[0] });
    setEditingItem(null);
    setIsFormOpen(false);
  };

  const handleEditClick = (item: ConfectioneryItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      price: item.price.toString(),
      category: item.category
    });
    setIsFormOpen(true);
  };

  const handleOpenCreate = () => {
    setEditingItem(null);
    setFormData({ name: '', price: '', category: CONFECTIONERY_CATEGORIES[0] });
    setIsFormOpen(true);
  };

  const handleApplyBulkAdjust = () => {
    const val = parseFloat(adjustConfig.value);
    if (isNaN(val) || val <= 0) return;

    onBulkAdjust(adjustConfig.type, adjustConfig.amountType, val, adjustConfig.category);
    
    // Feedback and reset
    setShowAdjustSuccess(true);
    setAdjustConfig(prev => ({ ...prev, value: '' }));
    setTimeout(() => {
      setShowAdjustSuccess(false);
      setIsAdjusterOpen(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Search and Quick Actions Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3.5 top-3.5 text-cocoa-400" />
          <input
            type="text"
            placeholder="Search items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-3 bg-white rounded-2xl border border-bakery-200 text-cocoa-800 text-sm focus:outline-none focus:ring-2 focus:ring-bakery-400 transition-all font-sans"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setIsAdjusterOpen(!isAdjusterOpen)}
            className="px-4 py-3 rounded-2xl bg-bakery-100 hover:bg-bakery-200 text-bakery-800 font-semibold text-xs flex items-center space-x-1.5 transition-colors border border-bakery-200"
          >
            <Percent className="w-4 h-4" />
            <span className="hidden xs:inline">Quick Pricing Adjust</span>
          </button>
          
          <button
            onClick={handleOpenCreate}
            className="px-4 py-3 rounded-2xl bg-rose-candy-500 hover:bg-rose-candy-600 text-white font-semibold text-xs flex items-center space-x-1.5 transition-colors shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Add Item</span>
          </button>
        </div>
      </div>

      {/* Bulk Price Adjuster Panel */}
      <AnimatePresence>
        {isAdjusterOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-bakery-50 border border-bakery-200 rounded-3xl p-5 overflow-hidden"
          >
            <div className="flex justify-between items-center mb-4">
              <h4 className="font-display font-bold text-cocoa-800 text-sm uppercase tracking-wide flex items-center">
                <Tag className="w-4.5 h-4.5 mr-1.5 text-bakery-500" />
                Smart Pricing Adjuster
              </h4>
              <button onClick={() => setIsAdjusterOpen(false)} className="text-cocoa-400 hover:text-cocoa-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            {showAdjustSuccess ? (
              <div className="py-6 flex flex-col items-center justify-center space-y-2 text-emerald-700">
                <Check className="w-8 h-8 p-1.5 bg-emerald-100 rounded-full" />
                <span className="text-sm font-semibold">Pricing adjusted successfully!</span>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-xxs text-cocoa-500 leading-relaxed">
                  Bulk adjust confectionery menu prices in real time. Perfect for seasonal discounts, holiday happy hours, or material cost corrections. Does not affect past bills.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                  {/* Category Filter for adjustment */}
                  <div>
                    <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Target Category</label>
                    <select
                      value={adjustConfig.category}
                      onChange={(e) => setAdjustConfig(prev => ({ ...prev, category: e.target.value }))}
                      className="w-full p-2.5 bg-white border border-bakery-200 rounded-xl text-xs text-cocoa-800 focus:outline-none"
                    >
                      <option value="all">All Sweet Items</option>
                      {CONFECTIONERY_CATEGORIES.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* Increase vs Decrease */}
                  <div>
                    <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Direction</label>
                    <div className="flex bg-white rounded-xl border border-bakery-200 p-0.5">
                      <button
                        onClick={() => setAdjustConfig(prev => ({ ...prev, type: 'increase' }))}
                        className={`flex-1 py-1.5 rounded-lg text-xxs font-semibold flex items-center justify-center space-x-1 ${adjustConfig.type === 'increase' ? 'bg-emerald-500 text-white' : 'text-cocoa-600 hover:bg-cocoa-50'}`}
                      >
                        <TrendingUp className="w-3 h-3" />
                        <span>Price Increase</span>
                      </button>
                      <button
                        onClick={() => setAdjustConfig(prev => ({ ...prev, type: 'decrease' }))}
                        className={`flex-1 py-1.5 rounded-lg text-xxs font-semibold flex items-center justify-center space-x-1 ${adjustConfig.type === 'decrease' ? 'bg-amber-500 text-white' : 'text-cocoa-600 hover:bg-cocoa-50'}`}
                      >
                        <TrendingDown className="w-3 h-3" />
                        <span>Discount</span>
                      </button>
                    </div>
                  </div>

                  {/* Flat vs Percent */}
                  <div>
                    <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Adjustment Mode</label>
                    <div className="flex bg-white rounded-xl border border-bakery-200 p-0.5">
                      <button
                        onClick={() => setAdjustConfig(prev => ({ ...prev, amountType: 'percent' }))}
                        className={`flex-1 py-1.5 rounded-lg text-xxs font-semibold flex items-center justify-center space-x-1 ${adjustConfig.amountType === 'percent' ? 'bg-rose-candy-500 text-white' : 'text-cocoa-600 hover:bg-cocoa-50'}`}
                      >
                        <Percent className="w-3 h-3" />
                        <span>Percentage (%)</span>
                      </button>
                      <button
                        onClick={() => setAdjustConfig(prev => ({ ...prev, amountType: 'flat' }))}
                        className={`flex-1 py-1.5 rounded-lg text-xxs font-semibold flex items-center justify-center space-x-1 ${adjustConfig.amountType === 'flat' ? 'bg-rose-candy-500 text-white' : 'text-cocoa-600 hover:bg-cocoa-50'}`}
                      >
                        <DollarSign className="w-3 h-3" />
                        <span>Flat Amount (Rs.)</span>
                      </button>
                    </div>
                  </div>
 
                  {/* Value */}
                  <div>
                    <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Adjustment Value</label>
                    <div className="relative">
                      <input
                        type="number"
                        placeholder={adjustConfig.amountType === 'percent' ? '15' : '50'}
                        value={adjustConfig.value}
                        onChange={(e) => setAdjustConfig(prev => ({ ...prev, value: e.target.value }))}
                        className="w-full p-2.5 bg-white border border-bakery-200 rounded-xl text-xs text-cocoa-800 pr-8 focus:outline-none focus:ring-1 focus:ring-bakery-400"
                        min="0"
                        step={adjustConfig.amountType === 'percent' ? '1' : '1'}
                      />
                      <span className="absolute right-3 top-3 text-xxs font-bold text-cocoa-400">
                        {adjustConfig.amountType === 'percent' ? '%' : 'Rs.'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end pt-2">
                  <button
                    onClick={handleApplyBulkAdjust}
                    disabled={!adjustConfig.value || parseFloat(adjustConfig.value) <= 0}
                    className="px-5 py-2.5 rounded-xl bg-cocoa-800 hover:bg-cocoa-900 disabled:bg-cocoa-300 disabled:cursor-not-allowed text-white font-semibold text-xs flex items-center space-x-1.5 transition-colors shadow-sm"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Apply Price Adjustment</span>
                  </button>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Categories Filter Tabs */}
      <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setSelectedCategory('All')}
          className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-colors border ${
            selectedCategory === 'All'
              ? 'bg-cocoa-800 border-cocoa-800 text-white shadow-sm'
              : 'bg-white border-bakery-200 text-cocoa-600 hover:bg-bakery-50'
          }`}
        >
          All Items ({items.length})
        </button>
        {CONFECTIONERY_CATEGORIES.map(category => {
          const count = items.filter(item => item.category === category).length;
          return (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-colors border ${
                selectedCategory === category
                  ? 'bg-cocoa-800 border-cocoa-800 text-white shadow-sm'
                  : 'bg-white border-bakery-200 text-cocoa-600 hover:bg-bakery-50'
              }`}
            >
              {category} ({count})
            </button>
          );
        })}
      </div>

      {/* Add / Edit Overlay Form Modal */}
      <AnimatePresence>
        {isFormOpen && (
          <div className="fixed inset-0 bg-black/40 backdrop-blur-xxs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 shadow-xl border border-bakery-100 w-full max-w-md"
            >
              <div className="flex justify-between items-center mb-5">
                <h3 className="font-display font-bold text-cocoa-800 text-base">
                  {editingItem ? 'Edit Confectionery Item' : 'Add New Sweet Item'}
                </h3>
                <button
                  onClick={() => setIsFormOpen(false)}
                  className="p-1.5 rounded-full hover:bg-cocoa-100 text-cocoa-400 hover:text-cocoa-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Item Name */}
                <div>
                  <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Item Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Lavender Fudge, Raspberry Tart..."
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full p-3 bg-cocoa-50 border border-bakery-100 rounded-xl text-xs text-cocoa-800 focus:outline-none focus:ring-1 focus:ring-bakery-400 font-sans"
                  />
                </div>

                {/* Category Selection */}
                <div>
                  <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Category Group</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full p-3 bg-cocoa-50 border border-bakery-100 rounded-xl text-xs text-cocoa-800 focus:outline-none focus:ring-1 focus:ring-bakery-400"
                  >
                    {CONFECTIONERY_CATEGORIES.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>

                {/* Price */}
                <div>
                  <label className="block text-xxs font-semibold text-cocoa-600 mb-1">Price (Rs.)</label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3.5 text-cocoa-400 text-xs font-semibold">Rs.</span>
                    <input
                      type="number"
                      required
                      step="1"
                      min="0"
                      placeholder="150"
                      value={formData.price}
                      onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                      className="w-full pl-12 pr-4 py-3 bg-cocoa-50 border border-bakery-100 rounded-xl text-xs text-cocoa-800 focus:outline-none focus:ring-1 focus:ring-bakery-400 font-sans"
                    />
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3 pt-3">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="flex-1 py-3 border border-cocoa-200 text-cocoa-600 rounded-2xl text-xs font-semibold hover:bg-cocoa-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-rose-candy-500 hover:bg-rose-candy-600 text-white rounded-2xl text-xs font-semibold shadow-md shadow-rose-candy-100"
                  >
                    {editingItem ? 'Save Changes' : 'Create Item'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Confectionery Items List Grid */}
      <div className="bg-white rounded-3xl shadow-sm border border-bakery-100 overflow-hidden">
        {filteredItems.length === 0 ? (
          <div className="p-12 text-center text-cocoa-400 space-y-2">
            <Layers className="w-8 h-8 mx-auto text-bakery-300" />
            <p className="text-xs font-medium">No sweet items found.</p>
            <p className="text-xxs">Try adjustments, adding items or clearing search.</p>
          </div>
        ) : (
          <div className="divide-y divide-bakery-100">
            {filteredItems.map(item => (
              <div key={item.id} className="p-4 flex items-center justify-between hover:bg-bakery-50/50 transition-colors">
                <div className="space-y-1 pr-4">
                  <h5 className="font-display font-semibold text-cocoa-800 text-sm">{item.name}</h5>
                  <div className="flex items-center space-x-2 text-xxs text-cocoa-500">
                    <span className="px-2 py-0.5 rounded-full bg-bakery-100 text-bakery-800 font-semibold">{item.category}</span>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <span className="font-sans font-bold text-cocoa-900 text-sm">
                    Rs. {item.price.toLocaleString()}
                  </span>
                  
                  <div className="flex space-x-1">
                    <button
                      onClick={() => handleEditClick(item)}
                      className="p-2 rounded-xl text-cocoa-500 hover:text-bakery-800 hover:bg-bakery-100 transition-colors"
                      title="Edit Item"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="p-2 rounded-xl text-cocoa-400 hover:text-rose-candy-500 hover:bg-rose-candy-50 transition-colors"
                      title="Delete Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
