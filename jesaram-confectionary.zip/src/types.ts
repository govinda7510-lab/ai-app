export interface ConfectioneryItem {
  id: string;
  name: string;
  price: number;
  category: string;
  createdAt: string;
}

export interface CartItem {
  item: ConfectioneryItem;
  quantity: number;
}

export interface Transaction {
  id: string;
  billNumber: string;
  items: CartItem[];
  total: number;
  dateTime: string;
  paymentMethod: 'Cash' | 'Card' | 'UPI' | 'Mobile';
  customerName?: string;
}

export type ActiveTab = 'sales' | 'admin' | 'transactions' | 'printer';

export interface BluetoothPrinterState {
  isConnected: boolean;
  isConnecting: boolean;
  deviceName: string | null;
  error: string | null;
  logs: string[];
}
